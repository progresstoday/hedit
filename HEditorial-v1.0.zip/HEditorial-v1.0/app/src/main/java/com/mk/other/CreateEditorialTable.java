package com.mk.other;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.mk.R;

import java.util.HashMap;

public class CreateEditorialTable {
    static float titleFontSize = 20.0f, introFontSize = 19.0f, bodyFontSize = 18.0f;
    static int padding = 15;
    static int padding2 = 50;
    static float ls = 15.0f;

    public static void addTable(Context ct, LinearLayout view, String title, String intro, HashMap<Integer, String> body) {
        TableLayout editorial_table = new TableLayout(ct);
        editorial_table.setBackgroundResource(R.drawable.row_border);
        editorial_table.setPadding(padding2,padding2,padding2,0);
        addRow(ct,editorial_table,title, "title");
        addRow(ct,editorial_table,intro, "intro");
        for(int i=0;i<body.size();i++) {
            addRow(ct,editorial_table,body.get(i),"");
        }
        view.addView(editorial_table);
    }

    public static void addRow(Context ct,TableLayout table, String text, String type) {
        TableRow titleRow = new TableRow(ct);
        titleRow.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT,TableRow.LayoutParams.FILL_PARENT));
        titleRow.setWeightSum(2);
//        titleRow.setBackgroundResource(R.drawable.row_border);
        if("title".equalsIgnoreCase(type)) {
            addTitleTextView(ct,titleRow,text);
        } else if("intro".equalsIgnoreCase(type)) {
            addIntroTextView(ct, titleRow, text);
        } else {
            addTextView(ct, titleRow, text);
        }
        table.addView(titleRow);
    }

    public static void addTitleTextView(Context ct,TableRow row, String text) {
        TextView textView = new TextView(ct);
        textView.setText(text);
//        textView.setGravity(Gravity.CENTER);
        textView.setTextColor(Color.parseColor("#000000"));
        textView.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT,TableRow.LayoutParams.FILL_PARENT,2f));
        textView.setPadding(padding,padding,padding,padding);
        textView.setTextSize(titleFontSize);
        textView.setTypeface(null, Typeface.BOLD);
        textView.setLineSpacing(ls,1.0f);
        textView.setTextIsSelectable(true);
        row.addView(textView);
    }

    public static void addIntroTextView(Context ct,TableRow row, String text) {
        TextView textView = new TextView(ct);
        textView.setText(text);
//        textView.setGravity(Gravity.RIGHT);
        textView.setTextColor(Color.parseColor("#000000"));
        textView.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT,TableRow.LayoutParams.FILL_PARENT,2f));
        textView.setPadding(padding,padding,padding,padding);
        textView.setTextSize(introFontSize);
        textView.setTypeface(null, Typeface.ITALIC);
        textView.setLineSpacing(ls,1.0f);
        textView.setTextIsSelectable(true);
        row.addView(textView);
    }

    public static void addTextView(Context ct,TableRow row, String text) {
        TextView textView = new TextView(ct);
        textView.setText(text);
//        textView.setGravity(Gravity.FILL_HORIZONTAL);
//        textView.setTextColor(Color.parseColor("#FFFFFF"));
        textView.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT,TableRow.LayoutParams.FILL_PARENT,2f));
        textView.setPadding(padding,padding,padding,0);
        textView.setTextSize(bodyFontSize);
        textView.setLineSpacing(ls,1.0f);
        textView.setTextIsSelectable(true);
        row.addView(textView);
    }

    public static void addErrorTextView(Context ct,LinearLayout layout, String text) {
        TextView textView = new TextView(ct);
        textView.setText(text);
        textView.setGravity(Gravity.CENTER_HORIZONTAL);
//        hcol3.setTextColor(Color.parseColor("#FFFFFF"));
        textView.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT,TableRow.LayoutParams.FILL_PARENT,2f));
//        hcol3.setPadding(padding,padding,padding,padding);
        layout.addView(textView);
    }
}
