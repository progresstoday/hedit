package com.mk.other;

import android.content.Context;
import android.widget.LinearLayout;

import org.jsoup.Jsoup;
import org.jsoup.helper.HttpConnection;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.HashMap;

public class Editorial {

    static final String hinduEditorialsURL = "https://www.thehindu.com/opinion/editorial/";
    static final String editorialsLinkCss = "a[class*='ES2'][class*='text1-heading']";
    static final String titleCss = "h1.title";
    static final String introCss = "h2.intro";
    static final String bodyCss = "div[id*='content-body']>p";

    public static void getEditorial(Context ct, LinearLayout layout) {
        try {
            editorial(ct,layout);
        } catch (Exception e) {
            errorMsg(ct,layout);
        }
    }

    public static void editorial(Context ct, LinearLayout layout) throws Exception {
        Document doc = Jsoup.connect(hinduEditorialsURL).get();
        if(doc==null) {
            errorMsg(ct,layout);
            return;
        }

        for(Element editorialLink: doc.select(editorialsLinkCss)) {
            Document editorialDoc = Jsoup.connect(editorialLink.attr("href")).get();
            String editorialTitle = editorialDoc.selectFirst(titleCss).text();
            String editorialIntro = editorialDoc.selectFirst(introCss).text();
            HashMap<Integer,String> editorialBody = editorialBody(editorialDoc.select(bodyCss));
//            printEditorialData(editorialTitle, editorialIntro, editorialBody);
            CreateEditorialTable.addTable(ct,layout,editorialTitle,editorialIntro,editorialBody);
        }

    }

    public static HashMap<Integer,String> editorialBody(Elements bodyElements) {
        HashMap<Integer,String> bodyTextMap = new HashMap<>();
        for(int i=0;i<bodyElements.size();i++) {
            bodyTextMap.put(i,bodyElements.get(i).text());
        }
        return bodyTextMap;
    }

    public static void printEditorialData(String editorialTitle,String editorialIntro,HashMap<Integer,String> editorialBody) {
        System.out.println(editorialTitle);
        System.out.println(editorialIntro);
        for(int i=0;i<editorialBody.size();i++) {
            System.out.println(editorialBody.get(i));
        }
        System.out.println("-----");
    }

    public static void errorMsg(Context ct, LinearLayout layout) {
        System.out.println("Unable to retrieve editorials.");
        CreateEditorialTable.addErrorTextView(ct,layout,"Unable to retrieve editorials.");
    }
}
