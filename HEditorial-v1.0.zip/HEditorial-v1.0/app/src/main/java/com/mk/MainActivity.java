package com.mk;

import android.content.Context;
import android.graphics.Color;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.mk.other.CreateEditorialTable;
import com.mk.other.Editorial;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    static final String hinduEditorialsURL = "https://www.thehindu.com/opinion/editorial/";
    static final String editorialsLinkCss = "a[class*='ES2'][class*='text1-heading']";
    static final String titleCss = "h1.title";
    static final String introCss = "h2.intro";
    static final String bodyCss = "div[id*='content-body']>p";

    Context ct = this;
    LinearLayout layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setTitle("HEditorial - "+getTodaysDate());
        setContentView(R.layout.activity_main);


        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new
                    StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        layout = (LinearLayout) findViewById(R.id.editorial_view);
        System.out.println("Before ------------->");
        Editorial.getEditorial(ct,layout);
        System.out.println("Before2 ------------->");

    }

    private String getTodaysDate() {
        return new SimpleDateFormat("dd/MM/yyyy").format(new Date());
    }
}
